# @vyrechain/sdk

TypeScript SDK for VYRE, the People's Layer: a fast, EVM-compatible blockchain with USDC for gas. It gives you
the chain definitions, the contract addresses and ABIs, and functions for the launchpad (read launches, prices and
trades, quote, launch, buy, sell, and the creator's controls), deposits from Arc, USDC from other chains to Arc
(Circle's CCTP), withdrawals back to Arc, and the test-USDC faucet. Built on [viem](https://viem.sh).

**Testnet only for now** (chain ID 7357). Test USDC has no value.

## Install

```sh
npm i https://vyrechain.com/sdk/vyrechain-sdk-0.2.0.tgz viem
```

(On npm later.) ESM only; Node 18+ or any modern bundler. viem 2 is a peer dependency.

## The network

| | VYRE testnet | Arc testnet (parent chain) |
| --- | --- | --- |
| Chain ID | 7357 | 5042002 |
| RPC | https://testnet-rpc.vyrechain.com | https://rpc.testnet.arc.io |
| Explorer | https://explorer.vyrechain.com | https://testnet.arcscan.app |
| Gas | USDC, native, 18 decimals | USDC, native, 18 decimals |
| In the SDK | `vyreTestnet` | `arcTestnet` |

The public RPC takes plain `eth_`/`net_`/`web3_` calls, one request at a time per caller, with a per-caller budget
(contract reads and gas estimates cost the most: about two a second after a short burst). `vyreHttp()` is viem's
`http()` transport with retries set for that; use it, or your own node. `getAddresses(7357)` returns every contract
address.

## Quick start: read the latest launches

```ts
import { createPublicClient } from 'viem';
import { vyreTestnet, vyreHttp, getLaunches, formatUsdc, quoteBuy, parseUsdc } from '@vyrechain/sdk';

const client = createPublicClient({ chain: vyreTestnet, transport: vyreHttp() });

const launches = await getLaunches(client, { count: 5 }); // newest first
for (const l of launches) {
  console.log(l.symbol, l.name, l.token, `tax ${l.buyTaxBps / 100}% / ${l.sellTaxBps / 100}%`);
}

// what 1 USDC buys now
const tokens = await quoteBuy(client, { token: launches[0].token, usdcIn: parseUsdc('1') });
console.log(formatUsdc(tokens)); // launch tokens have 18 decimals too
```

`getLaunch(client, token)` returns one launch (or `null` if the token isn't one); `getLaunchCount(client)` counts them.

## Buy and sell

Trades go through VYRE's app router with native USDC in and out.

```ts
import { createWalletClient } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { vyreTestnet, vyreHttp, buy, sell, parseUsdc } from '@vyrechain/sdk';

// a script: a throwaway test key from the environment (never in code or a repo)
const account = privateKeyToAccount(process.env.PRIVATE_KEY as `0x${string}`);
const wallet = createWalletClient({ account, chain: vyreTestnet, transport: vyreHttp() });

const bought = await buy(wallet, client, { token, usdcIn: parseUsdc('1') });
console.log(`got ${bought.tokensOut} for ${bought.usdcIn}`, bought.hash);

const sold = await sell(wallet, client, { token, amountIn: bought.tokensOut });
console.log(`got ${sold.usdcOut} USDC back`, sold.approval); // 'permit', 'approve' or 'allowance'
```

In a browser, use the user's wallet instead:

```ts
import { createWalletClient, custom } from 'viem';

const [address] = await window.ethereum.request({ method: 'eth_requestAccounts' });
const wallet = createWalletClient({ account: address, chain: vyreTestnet, transport: custom(window.ethereum) });
await wallet.addChain({ chain: vyreTestnet }); // once: adds VYRE testnet to the wallet
await wallet.switchChain({ id: vyreTestnet.id });
```

How trades work:

- **Every write is simulated first** and only sent if the simulation passes, so a trade that would fail stops before
  the wallet is asked to sign. Gas is estimated with a 20% margin.
- **Slippage**: by default a trade accepts up to 2% less than the quote (`slippageBps`, or set `minTokensOut` /
  `minUsdcOut` yourself). Anyone can trade at any time, so another trade can land in between. A trade must be mined
  within 10 minutes (`deadline`, unix seconds).
- **Selling needs the router to move your tokens.** If it isn't allowed yet, `sell` signs an EIP-2612 permit for
  exactly `amountIn` (no extra transaction). If the wallet can't sign one, it sends an approval for exactly `amountIn`
  and waits for it (`permit: false` always does this). Approvals are never unlimited.
- `sell` refuses when the pool would pay nothing (a pool holds only the USDC its buyers paid in).
- **Fees**, all in USDC: the creator's tax (0-10% per side, set at launch, can only go down), VYRE's 1%, and a partner
  launchpad's fee if the launch names one (up to 1%). The router's own app fee is 0 (`getAppFeeBps`). Quotes include
  all of them.
- **Promoters**: `setPromoter(wallet, client, promoter)` names who brought a wallet, once and for good
  (`getPromoter` reads it). Once the promoter is approved (`isApprovedPromoter`), they get a share of VYRE's 1% on that
  wallet's trades through the router, paid on the spot. It never costs the trader anything.

## Launch a token

```ts
import { launch, parseUsdc } from '@vyrechain/sdk';
import { parseUnits } from 'viem';

const { token, pool, bought, hash } = await launch(wallet, client, {
  name: 'My Token',
  symbol: 'MINE',
  totalSupply: parseUnits('1000000000', 18), // 1,000 to 1 quadrillion whole tokens
  // (no market cap to pick: every launch opens at $3,000, LAUNCH_LIMITS.openingMarketCap)
  buyTaxBps: 100, // your tax on buys, 0-1,000 (10%), earned in USDC
  sellTaxBps: 100,
  metadataURI: 'https://example.com/mine.json', // picture, description and links; optional, up to 256 bytes
  firstBuyUsdc: parseUsdc('10'), // optional: your own first buy, in the same transaction
});
```

One transaction makes the token, opens its pool at the fixed $3,000 opening market cap with the whole supply in it (locked for
good) and, with `firstBuyUsdc`, makes your first buy before anyone else can trade. The limits are checked before
anything is sent (`checkLaunchParams`, `LAUNCH_LIMITS`). Another launchpad launching for its creators can add
`partner` and `partnerFeeBps` (up to 100, 1%).

## Markets and trades

```ts
import { getMarket, getTrades, formatPrice, formatUsdc } from '@vyrechain/sdk';

const m = await getMarket(client, token); // or a Launch from getLaunch / getLaunches: 1 read instead of 3
console.log(`${formatPrice(m.price)} USDC a token, market cap ${formatUsdc(m.marketCap)} USDC`);

const trades = await getTrades(client, { token, limit: 20 }); // newest first
for (const t of trades) console.log(t.isBuy ? 'buy' : 'sale', formatUsdc(t.tokens), 'for', formatUsdc(t.usdc), t.hash);
```

- `price` is USDC per whole token as a bigint scaled by 1e18, worked out exactly (integer math, rounded down) from the
  pool's `sqrtPriceX96`; `marketCap` is the whole supply at that price, in USDC. It's the pool's mid price, before
  fees (quotes include every fee). `formatPrice` rounds to 6 significant digits; `sqrtPriceX96ToPrice` and
  `sqrtPriceX96ToMarketCap` do the same math on any price (a Swap event's, say).
- `getTrades` reads the pool's Swap events: trades through any router, and the creator's first buy at launch. `usdc`
  is what the pool took on a buy (its fees included) or paid out on a sale (after its fees), before any app fee.
  By default it searches from the pad's deployment block to the latest, 50,000 blocks per query from the newest back,
  and stops once it has `limit` trades; `fromBlock` and `toBlock` narrow it. A trade's time is its block's
  (`client.getBlock({ blockNumber })`).

## Creator controls

A launch's creator (the wallet that launched it, or the one it was handed to) manages it with these. Like every write
here, each is checked against the pad's rules, simulated, and only then sent; each returns `{ hash, receipt }`.

```ts
import { collectCreatorFees, lowerTaxes, setTaxWallets, setMetadata, offerCreator, acceptCreator } from '@vyrechain/sdk';

const { amount, paid } = await collectCreatorFees(wallet, client, { token }); // the tax so far
await lowerTaxes(wallet, client, { token, buyTaxBps: 100, sellTaxBps: 200 });
await setTaxWallets(wallet, client, { token, wallets: [me, teammate], bps: [7_000, 3_000] });
await setMetadata(wallet, client, { token, metadataURI: 'https://example.com/mine-v2.json' });
await offerCreator(wallet, client, { token, to: newCreator });
await acceptCreator(newCreatorWallet, client, { token }); // sent by the new creator
```

- **Collecting**: anyone may call `collectCreatorFees`; the tax can only go to the creator or their tax wallets. It's
  paid in WUSDC (USDC wrapped one to one; WUSDC's `withdraw(amount)` turns it back into native USDC). The result says
  how much and to whom (`amount`, `paid`).
- **Taxes** only go down: 0 to 1,000 bps each, neither above what it is now, and at least one lower. The pool's fees
  drop at once.
- **Tax wallets**: 1 to 4, with shares in bps that are each above 0 and add up to 10,000. The tax so far is paid out
  first, where it was set to go. VYRE's own contracts, the chain's Multicall3 and the launch's own pool and token are
  refused (tax sent there would be lost or open to anyone); name only wallets that can move WUSDC.
  `getTaxWallets(client, token)` reads them (both lists empty: it all goes to the creator).
- **Metadata**: a link of up to 256 bytes; `''` clears it.
- **Handing over** takes two steps: `offerCreator`, then `acceptCreator` from the new creator's wallet
  (`getPendingCreator` shows who it's offered to). The pad only takes the handover at the taxes the new creator
  expects, since the outgoing creator could still lower them: `acceptCreator` reads them just before, or pass
  `buyTaxBps` and `sellTaxBps` to hold out for those. The tax so far goes where it was set to go, and the new creator
  starts with no tax wallets. An offer to the zero address withdraws it.

## Bring USDC from Arc

```ts
import { createPublicClient, createWalletClient } from 'viem';
import { arcTestnet, vyreHttp, depositFromArc, waitForDeposit, parseUsdc } from '@vyrechain/sdk';

const arc = createPublicClient({ chain: arcTestnet, transport: vyreHttp() });
const arcWallet = createWalletClient({ account, chain: arcTestnet, transport: vyreHttp() });

const before = await client.getBalance({ address: account.address }); // on VYRE
await depositFromArc(arcWallet, arc, { amount: parseUsdc('5') });
const after = await waitForDeposit(client, { address: account.address, before });
```

The same address is credited on VYRE, usually within seconds. Deposit from a plain wallet: a contract or smart
account on Arc is credited at a different (aliased) address, so `depositFromArc` refuses a sender with code on Arc
unless you pass `allowAliased: true`; `aliasOf(address)` gives the address it would be credited at. (A smart account
not yet deployed has no code to check: deposit from a plain wallet.) Test USDC on Arc comes from
https://faucet.circle.com.

## Bring USDC from another chain

USDC on Ethereum Sepolia, Base Sepolia or Arbitrum Sepolia reaches Arc through Circle's CCTP: it's burned there, and
Circle mints it on Arc and delivers that mint itself (its Forwarding Service, which pays Arc's gas). From Arc, move it
to VYRE with `depositFromArc`.

```ts
import { createPublicClient, createWalletClient, custom, http, parseUnits } from 'viem';
import { cctpSource, quoteFromChain, burnToArc, waitForArcMint, toNativeUsdc } from '@vyrechain/sdk';

const base = cctpSource(84_532); // Base Sepolia; CCTP_SOURCES lists all three
const baseClient = createPublicClient({ chain: base.chain, transport: http() });
const baseWallet = createWalletClient({ account: address, chain: base.chain, transport: custom(window.ethereum) });

// amounts on the source chains have 6 decimals (USDC is an ERC-20 there)
const quote = await quoteFromChain({ sourceChainId: base.id, amount: parseUnits('10', 6) });
console.log(`Circle's fees: up to ${quote.maxFee}; about ${quote.receive} arrives on Arc`);

const burn = await burnToArc(baseWallet, baseClient, {
  amount: quote.amount,
  maxFee: quote.maxFee, // the most you accept: the burn pays Circle's fees at that moment, and stops if they're higher
  // 'approve', 'burn', then 'sent' with the burn's hash (and again with a new hash, and the one it replaces, if sped up)
  onProgress: (step, hash, replaces) => console.log(step, hash ?? '', replaces ?? ''),
});
const mint = await waitForArcMint(base.id, burn.hash, { recipient: burn.recipient, onStatus: (s) => console.log(s.stage) });
console.log('minted on Arc', mint.forwardTxHash, toNativeUsdc(mint.received ?? quote.receive)); // 18 decimals on Arc
```

- **Fees** (`getCctpFees`, `maxFeeFor`): Circle's fast-transfer fee (about 0.01% of the amount) plus its delivery fee
  on Arc (about 0.02 USDC; Circle's highest current estimate is used), worked out in integers and rounded up. They come
  out of the amount, and Circle keeps all of the maxFee a burn names. The delivery fee moves every few seconds with
  Arc's gas, so a quote has two figures: `fee`, what a burn sent now pays (`receive` is the amount less it), and
  `maxFee` (`feeCapFor`: `fee` plus half the delivery fee again), the most to accept (`receiveAtLeast`). The burn
  itself pays Circle's fees as they are when it's sent. Fees above `CCTP_FEE_LIMITS` (20 bps, 1 USDC) are refused as a
  broken or hijacked answer, as is anything the fee API says that can't be read.
- **`burnToArc` checks before anything is sent**: the wallet is on the public client's chain (one of `CCTP_SOURCES`),
  the recipient (default: the sender) isn't the zero address or a contract on Arc, a contract wallet's own address
  isn't used as the recipient (it may not be its owner's on Arc), the fees leave something to arrive and are within
  `maxFee`, and the wallet has the USDC and some ETH for gas. An approval, when the allowance is short, is for exactly
  the amount, never more. It reads Circle's fees again right before the burn (a `maxFee` below them wouldn't be
  delivered) and simulates every transaction first. `allowContractRecipient: true` lifts the recipient checks.
- **Keep the burn's hash** (`onProgress`'s 'sent' step comes before the burn is mined): it's how the transfer is
  followed. `waitForArcMint` polls Circle's API (`getArcMintStatus` reads it once), takes only answers about this burn,
  from its chain, to Arc (and to `recipient`, if given), reads the burn on the source chain until Circle has seen it,
  and returns once the mint is done on Arc. It throws `CctpBurnRevertedError` if the burn reverted (nothing was burned),
  `CctpDeliveryError` if Circle's delivery failed, and a plain error, saying where it stands, after `timeoutMs`
  (default 30 minutes): the transfer isn't lost then; check again later.
- **When Circle doesn't deliver** (its delivery failed, or a burn's `maxFee` was too low for it), anyone can mint the
  signed transfer on Arc: `mintOnArc(arcWallet, arc, { message, attestation })`, from the status's `message` and
  `attestation`.
- A fast transfer arrives in seconds from Base or Arbitrum Sepolia, about 20 s more from Ethereum Sepolia; the standard
  route (when Circle's fast lane is full) takes 15 to 19 minutes. Test USDC for these chains: https://faucet.circle.com.

## Move USDC back to Arc

A withdrawal takes two transactions with a wait between them: until VYRE's state covering it is confirmed on Arc
(usually under half an hour on the testnet).

```ts
import { withdrawToArc, getWithdrawals, getWithdrawalStatus, claimWithdrawal, parseUsdc } from '@vyrechain/sdk';

// 1. on VYRE: the USDC leaves the balance at once
const { withdrawal } = await withdrawToArc(wallet, client, { amount: parseUsdc('1') }); // to the sender's own address
// (a contract wallet on VYRE must pass `destination`: it may not control the same address on Arc)

// later (or from another device): find it again, and check it (`caller` keeps only the ones you started: anyone can
// start one paying to any address)
const [latest] = await getWithdrawals(client, { destination: account.address, caller: account.address });
const { state } = await getWithdrawalStatus(client, arc, latest); // 'waiting' | 'ready' | 'claimed'
// destination unknown? leave it out: every withdrawal `caller` started, to any address. Every page then holds every
// withdrawal made in it, so keep the range short with `fromBlock` (and bigger pages with `pageBlocks`)
// const mine = await getWithdrawals(client, { caller: account.address, fromBlock: recentBlock, pageBlocks: 500_000n });

// 2. on Arc, once it's ready: the proof comes from VYRE's node; the claimer pays Arc gas, the destination gets the USDC
if (state === 'ready') await claimWithdrawal(arcWallet, arc, client, latest);
```

`getConfirmedCount(client, arc)` gives how many of VYRE's withdrawals the rollup has confirmed on Arc (a withdrawal is
ready once its `position` is below it), for checking many at once.

## Test USDC faucet

```ts
import { requestTestUsdc, getFaucetStatus, FaucetError } from '@vyrechain/sdk';

try {
  const { tx, amount } = await requestTestUsdc(account.address);
  console.log(`sent ${amount} test USDC`, tx);
} catch (e) {
  if (e instanceof FaucetError && e.retryAfter) console.log(`try again in ${e.retryAfter} s`);
  else throw e;
}
console.log(await getFaucetStatus()); // { address, balance, drip, cooldownHours, open }
```

It sends test USDC straight to an address on VYRE testnet: no wallet connection, nothing to sign.

## Everything else

- All amounts are `bigint` with 18 decimals: native USDC on VYRE and on Arc, and every launch token. `parseUsdc` and
  `formatUsdc` convert. (Arc's ERC-20 view of USDC uses 6 decimals; the SDK only uses native balances.) The exception
  is the CCTP functions, which use the source chains' 6-decimal USDC (`toNativeUsdc` converts).
- Contracts and ABIs: `getAddresses(chainId)`, `vyrePadAbi`, `vyreAppRouterAbi`, `vyreReferralsAbi`,
  `vyreFeeSplitterAbi`, `vyreTokenAbi` (ERC-20 with permit), `quoterV2Abi`, `vyrePoolAbi` (a pad pool: Uniswap v3's
  pool with separate buy and sell fees), `inboxAbi`, for withdrawals `arbSysAbi`, `outboxAbi`, `rollupAbi`,
  `nodeInterfaceAbi`, and for Circle's CCTP `tokenMessengerV2Abi` and `messageTransmitterV2Abi` (their addresses:
  `CCTP_TOKEN_MESSENGER`, `CCTP_MESSAGE_TRANSMITTER`).
- Sends are simulated first and wait for their receipt. If a transaction was sent but its receipt couldn't be read in
  time, they throw `SentButUnconfirmedError` (`hash`, `chainId`, `cause`): it was sent, so check it rather than send
  it again. One sped up in the wallet returns its new hash (and `burnToArc`'s `onProgress` gets `'sent'` again with
  the new hash and the one it replaces); one cancelled or replaced by a different transaction throws
  `TransactionReplacedError` (`hash`, `replacement`, `reason`): nothing was done.
- A local node or your own deployment of the contracts: `registerDeployment(chainId, addresses)`, then every function
  works on that chain.
- Reads run one after another (the public RPC answers one request at a time). A client made with
  `batch: { multicall: true }` runs them together through Multicall3 (VYRE testnet has one; its address is in
  `vyreTestnet`): `createPublicClient({ chain: vyreTestnet, transport: vyreHttp(), batch: { multicall: true } })`.

## License

MIT. The contracts themselves are GPL-2.0-or-later (Uniswap v3's license).
